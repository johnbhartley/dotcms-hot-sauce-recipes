<template>
  <div class="about container">
    <h1>This is an about page</h1>
    <!-- eslint-disable-next-line -->
    <p data-dmc="section" class="article-section__content">There are thousands of types of hot peppers, and they tend to offer similar nutritional benefits. Take green chile peppers. One serving (half a cup) is low in calories, sugars and carbohydrates. It also contains little fat and no cholesterol. Nutrients include a whopping dose of Vitamin C.</p>
    <!-- eslint-disable-next-line -->
    <p data-dmc="section" class="article-section__content">Vitamin C is connected to fast metabolism, the development of connective tissue, biosynthesis of neurotransmitters, immune function, healing wounds and iron absorption. It’s also an antioxidant, which means it destroys free radicals that can enter and damage cells. Vitamin C is necessary for healthy skin, teeth and bones and even helps stave off scurvy.</p>
    <!-- eslint-disable-next-line -->
    <p data-dmc="section" class="article-section__content">Nutritionally, the hot chile pepper does not relent.</p>
    <!-- eslint-disable-next-line -->
    <p data-dmc="section" class="article-section__content">Hot chile peppers contain carotenoids (Vitamin A), flavonoids, antioxidants, vitamins and minerals, all of which confer health benefits, including anti-aging and anti-inflammatory properties, DNA protection and lower blood pressure.</p>
    <!-- eslint-disable-next-line -->
    <p data-dmc="section" class="article-section__content">The real wonder of chile peppers, though, is capsaicin, a colorless plant compound that gives hot peppers their heat and can be used for its analgesic properties: Yes, capsaicin is so powerful that it’s often used in pain-relieving topical creams.</p>
    <!-- eslint-disable-next-line -->
    <p data-dmc="section" class="article-section__content">Capsaicin is present in servings of hot peppers, hot sauces and salsas. Inside hot peppers, capsaicin is concentrated in the placental tissue that holds the seeds, as well as in pod walls. Contrary to popular belief, it’s not the seeds that bring the heat, although seeds can be hot. The heat found in seeds is absorbed from the placental tissues.</p>
    <!-- eslint-disable-next-line -->
    <p data-dmc="section" class="article-section__content">How hot is capsaicin? The Scoville Scale is the standardized measure of pepper hotness. Traditional red Tabasco sauce represents 2,500 to 5,000 Scoville heat units. For pure capsaicin, the tally is 16 million Scoville heat units. The lesson: don’t put pure capsaicin in your soup for the health benefits, or else a rogue government may kidnap you and weaponize your face.</p>
  </div>
</template>

<script>
export default {
  name: 'about',
};
</script>
